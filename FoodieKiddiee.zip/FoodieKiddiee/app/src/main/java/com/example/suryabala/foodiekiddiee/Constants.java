package com.example.suryabala.foodiekiddiee;

/**
 * Created by suryabala on 9/12/2017.
 */

public class Constants {
    public static String status = "";
    static final String role = "parent";
    static final String PREFS_FILE = "PrefsFile";

    static final String loginUrl = "https://foodiekiddiee.000webhostapp.com/login.php";
    static final String regUrl = "https://foodiekiddiee.000webhostapp.com/Foodiekiddie-mom/parent_registration.php";
    static final String viewAccountUrl = "https://foodiekiddiee.000webhostapp.com/Foodiekiddie-mom/view_account.php";
    static final String editAccountUrl = "https://foodiekiddiee.000webhostapp.com/Foodiekiddie-mom/edit_account.php";
    static final String changePassUrl = "https://foodiekiddiee.000webhostapp.com/Foodiekiddie-mom/change_password.php";

}
